//
//  ViewController.h
//  iComico
//
//  Created by ane_it_ios on 16/8/17.
//  Copyright © 2016年 ane_it_ssk. All rights reserved.
//

#import <UIKit/UIKit.h>

//对应的TabBar控制器  这是StoryBoard中拖拽出来的
@interface ViewController : UITabBarController

@end

