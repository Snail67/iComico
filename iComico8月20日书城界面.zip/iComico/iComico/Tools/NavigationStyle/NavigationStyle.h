//
//  NavigationStyle.h
//  ComicReader
//
//  Created by Jiang on 14/12/11.
//  Copyright (c) 2014年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationStyle : UINavigationBar

@end
