//
//  MyComicController.h
//  iComico
//
//  Created by ane_it_ios on 16/8/18.
//  Copyright © 2016年 ane_it_ssk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyComicController : UIViewController

@end
