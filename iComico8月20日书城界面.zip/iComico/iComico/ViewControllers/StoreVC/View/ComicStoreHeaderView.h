//
//  StoreTableViewHeader.h
//  ComicReader
//
//  Created by Jiang on 14/12/10.
//  Copyright (c) 2014年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ComicStoreHeaderView : UICollectionReusableView
//- (instancetype)initWithDataModels:(NSArray*)modelArray;
@property (nonatomic, strong) NSArray *modelArray;
@end
