//
//  ResizeLabel.h
//  ComicReader
//
//  Created by Jiang on 1/12/15.
//  Copyright (c) 2015 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResizeLabel : UILabel

@end
